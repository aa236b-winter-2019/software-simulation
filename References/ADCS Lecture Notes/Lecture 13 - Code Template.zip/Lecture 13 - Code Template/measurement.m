function [y,C] = measurement(q,rN)

QBN = 

rB = QBN*rN;

C = 

y = rB(:);

end

