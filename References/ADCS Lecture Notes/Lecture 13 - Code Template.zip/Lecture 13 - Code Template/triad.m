function [q,R] = triad(rN1,rN2,rB1,rB2)

R = 

q = 

end

