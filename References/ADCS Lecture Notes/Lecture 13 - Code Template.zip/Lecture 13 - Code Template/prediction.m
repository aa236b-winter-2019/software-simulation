function [xn,A] = prediction(xk,w,dt)

q = xk(1:4);
b = xk(5:7);

xn = 
A = 

end

